#!/bin/bash
#SBATCH -e err
#SBATCH -o out
#SBATCH --account=epic
#SBATCH --qos=batch
##SBATCH --partition=<partition>
#SBATCH --nodes=2
#SBATCH --ntasks-per-node=8
#SBATCH --time=00:00:30
#SBATCH --job-name="hello-world-parallel"

# These modules may need to be loaded on the host if the container runtime is
# not already in the default PATH.
#module load apptainer
#module load singularity

# Directory from which sbatch was submitted,
# or current directory when run interactively.
echo "PWD = $PWD"
work_dir="${SLURM_SUBMIT_DIR:-$PWD}"

# Container image is one directory above.
base_dir=$(dirname "$work_dir")
img="${base_dir}/rocky9-gcc13-ss192-ompi416.sif"

echo "Working directory : ${work_dir}"
echo "Base directory    : ${base_dir}"
echo "Container image   : ${img}"

if command -v singularity >/dev/null 2>&1; then
        container_cmd=singularity
elif command -v apptainer >/dev/null 2>&1; then
        container_cmd=apptainer
else
        echo "ERROR: Neither singularity nor apptainer was found in PATH."
        echo "Load a container runtime module on the host, for example:"
        echo "  module load singularity"
        echo "  module load apptainer"
        exit 1
fi

echo "Container runtime : ${container_cmd}"

if [ ! -f "${img}" ]; then
        echo "ERROR: Container image not found: ${img}"
        exit 1
fi

if [ ! -x "${work_dir}/hello-world-parallel" ]; then
        echo "ERROR: Executable not found or not executable: ${work_dir}/hello-world-parallel"
        echo "Build it first, for example with: sbatch ${work_dir}/job_compile.sh"
        exit 1
fi

cd "${work_dir}" || exit 1

nprocs=${SLURM_NTASKS:-1}
nnodes=${SLURM_NNODES:-1}
ntpn=${SLURM_NTASKS_PER_NODE:-1}

export SINGULARITY_SHELL=/bin/bash
export SINGULARITYENV_OMPI_MCA_btl="^openib"
export SINGULARITYENV_OMPI_MCA_btl_vader_single_copy_mechanism=none
export SINGULARITYENV_STARTUP_STAGGER_SECONDS=0

 srun --mpi=pmi2 -n "${nprocs}" \
                "${container_cmd}" exec \
                -B "${base_dir}:${base_dir}" \
                "${img}" \
        bash -c '
        source /usr/share/lmod/lmod/init/bash
        module use /opt/modulefiles
        module load gnu openmpi
            if [ "${SLURM_PROCID:-0}" -eq 0 ]; then
                    module list
            fi
            if [ "${STARTUP_STAGGER_SECONDS:-0}" -gt 0 ]; then
                    sleep $((SLURM_PROCID % STARTUP_STAGGER_SECONDS))
            fi
        ./hello-world-parallel '
# Running with arguments: replace the line above with the following
# two lines (uncomment them)
#        ./hello-world-parallel "$1" "$2" "$3"
#        ' bash "${nprocs}" "${nnodes}" "${ntpn}"

