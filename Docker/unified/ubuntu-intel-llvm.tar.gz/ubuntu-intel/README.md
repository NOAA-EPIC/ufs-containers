Blackpearl is @climbfuji's development system (Dell Laptop running Oracle Linux 9.1 under Windows WSL2).

The site config currently requires a manual copy of the correct packages_COMPILER.yaml to the environment site directory. This will be improved later.