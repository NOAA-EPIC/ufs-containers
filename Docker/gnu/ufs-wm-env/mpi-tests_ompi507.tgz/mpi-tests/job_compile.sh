#!/bin/sh
#SBATCH -e err
#SBATCH -o out
#SBATCH --account=epic
#SBATCH --qos=batch
##SBATCH --partition=<partition>
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=1
#SBATCH --cpus-per-task=4
#SBATCH --time=00:00:30
#SBATCH --job-name="hello-world-compile"

# These modules may need to be loaded on the host if the container runtime is
# not already in the default PATH.
#module load apptainer
#module load singularity

# Directory from which sbatch was submitted,
# or current directory when run interactively.
work_dir="${SLURM_SUBMIT_DIR:-$PWD}"
#
# Container image is one directory above.
base_dir=$(dirname "$work_dir")
img="${base_dir}/rocky9-gcc13-ss192-ompi507.sif"

echo "Working directory : ${work_dir}"
echo "Base directory    : ${base_dir}"
echo "Container image   : ${img}"

if command -v singularity >/dev/null 2>&1; then
   container_cmd=singularity
elif command -v apptainer >/dev/null 2>&1; then
   container_cmd=apptainer
else
   echo "ERROR: Neither singularity nor apptainer was found in PATH."
   echo "Load a container runtime module on the host, for example:"
   echo "  module load singularity"
   echo "  module load apptainer"
   exit 1
fi

echo "Container runtime : ${container_cmd}"

if [ ! -f "${img}" ]; then
   echo "ERROR: Container image not found: ${img}"
   exit 1
fi

if [ ! -f "${work_dir}/Makefile" ]; then
   echo "ERROR: Makefile not found in: ${work_dir}"
   exit 1
fi

cd "${work_dir}" || exit 1

"${container_cmd}" exec \
   -B "${base_dir}:${base_dir}" \
   "${img}" \
   bash -c '
    source /usr/share/lmod/lmod/init/bash
    module use /opt/modulefiles
    module load gnu openmpi
    module list
    make clean
    make -j "${SLURM_CPUS_PER_TASK:-4}"
   '

