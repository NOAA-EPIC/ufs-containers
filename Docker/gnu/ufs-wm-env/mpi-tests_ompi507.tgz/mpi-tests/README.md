# README file for MPI Test Programs for Singularity/Apptainer-Based OpenMPI Testing

Created 05-16-2026 nperlin - Natalie Perlin
Updated 09-02-2026 nperlin - adapted for GNU compilers / OpenMPI

This directory contains simple Fortran MPI test programs used to verify an
OpenMPI installation built with the GNU compiler suite.

The examples build serial and MPI test programs using a container. A batch
script shows how to run an MPI executable requesting two nodes, with or
without command-line arguments.

## Files

- `hello-world.f90` - simple serial-style Fortran test program.
- `hello-world-parallel.f90` - MPI hello-world test program.
- `Makefile` - builds the test executables with the OpenMPI `mpif90` wrapper.
- `job_compile.sh` - batch script for building the executables.
- `job_script.sh` - batch script for running an MPI test on two nodes.

## Assumptions

The scripts are configured for the NOAA AWS Cloud Service Provider environment
and assume that they are submitted from `mpi-tests`, with the container image
one directory above the working directory. The scheduler is Slurm, MPI ranks
are launched with `srun --mpi=pmi2`, and OpenMPI inside the container was built
with PMI2 support.

The host must have either `singularity` or `apptainer` in `PATH`. The scripts
check for `singularity` first, then `apptainer`. If neither runtime is found,
load the matching host module before submitting. The container image includes
GNU compilers, OpenMPI, and Lmod module files.

Other systems may require changes to the Slurm directives, account name,
queue or partition, container image name, and MPI runtime environment.

## Running the `hello-world-parallel` Test

The scripts set `work_dir` from `SLURM_SUBMIT_DIR` and `base_dir` to its parent.
The container image is expected at:

```bash
${base_dir}/rocky9-gcc13-ss192-ompi507.sif
```

For example, if the repository is staged as `/some/filesystem/mpi-tests`,
place the image at `/some/filesystem/rocky9-gnu13-ompi507.sif`.

### 1. Obtain or build a Singularity/Apptainer image

```bash
cd /some/filesystem
singularity pull rocky9-gcc13-ss192-ompi507.sif \
    docker://noaaepic/rocky9-gcc13.3.1-spack-stack:v1.9.2-ufs-env-ompi507
export img=/some/filesystem/rocky9-gcc13-ss192-ompi507.sif
```

Use `apptainer pull` instead when Singularity is unavailable.

### 2. Stage the test directory on the host

```bash
container_cmd=singularity
command -v "${container_cmd}" >/dev/null 2>&1 || container_cmd=apptainer
base_dir=/some/filesystem
"${container_cmd}" exec -B "${base_dir}:${base_dir}" "${img}" \
    cp -r /opt/mpi-tests "${base_dir}/."
```

### 3. Start an interactive shell inside the container

```bash
container_cmd=singularity
command -v "${container_cmd}" >/dev/null 2>&1 || container_cmd=apptainer
base_dir=/some/filesystem
"${container_cmd}" shell -B "${base_dir}:${base_dir}" "${img}"
```

Initialize Lmod and load GNU/OpenMPI:

```bash
source /usr/share/lmod/lmod/init/bash
module use /opt/modulefiles
module load gnu openmpi
module list
```

### 4. Build the executables

```bash
cd /some/filesystem/mpi-tests
make clean
make
```

Or build manually with `mpif90`:

```bash
make clean
mpif90 -o hello-world-parallel hello-world-parallel.f90
mpif90 -o hello-world hello-world.f90
```

Exit the container after building, or submit the batch build from `mpi-tests`:

```bash
exit
sbatch job_compile.sh
```

Before submitting, check the Slurm directives, account, queue or partition,
container image name, and host container runtime. Runtime module hints are
provided near the top of the batch scripts:

```bash
#module load apptainer
#module load singularity
```

## Running MPI Jobs

The default `job_script.sh` submits a two-node job with eight tasks per node:

```bash
sbatch job_script.sh
```

The script checks for `singularity` first, then `apptainer`, binds the parent
of the submit directory into the same path inside the container, and launches
ranks with `srun --mpi=pmi2`.

For this container workflow, the script exports:

```bash
export SINGULARITYENV_OMPI_MCA_btl="^openib"
export SINGULARITYENV_OMPI_MCA_btl_vader_single_copy_mechanism=none
```

For Apptainer-native environments, use the corresponding `APPTAINERENV_*`
variables. Adjust these settings for the interconnect and MPI configuration on
the target system.

Expected output in `out` should look similar to the following; rank order may
vary:

```text
 Hello, World! I am process           0 of          16
 Hello, World! I am process           8 of          16
 Hello, World! I am process           1 of          16
 Hello, World! I am process           2 of          16
```

## Passing Arguments to the MPI Program

To pass arguments through `job_script.sh`, replace the executable line in the
script with these two lines:

```bash
./hello-world-parallel "$1" "$2" "$3"
' bash "${nprocs}" "${nnodes}" "${ntpn}"
```

The Fortran test reports the number and values of the arguments received by
each MPI rank.
