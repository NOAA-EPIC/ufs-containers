# README file for MPI Test Programs for Singularity/Apptainer-Based Intel MPI Testing
Created 05-16-2026 nperlin - Natalie Perlin 
Updated 07-12-2026 nperlin
Updated 09-02-2026 nperlin - adapted for Intel oneAPI / Intel MPI
#

This directory contains simple Fortran MPI test programs used to verify an
Intel MPI installation built with the Intel oneAPI compiler suite.

The examples build serial and MPI test programs using a container.
A batch script shows how to run an MPI executable requesting two nodes
on a host system. It could be run with or without (default) command-line
arguments to the executable.

## Files

- `hello-world.f90` — simple serial-style Fortran test program.
- `hello-world-parallel.f90` — MPI hello-world test program.
- `Makefile` — builds the test executables.
- `job_compile.sh` — batch script for building the executables.
- `job_script.sh` — batch script for running an MPI test on two nodes, 
                    with or without command-line arguments

## Assumptions

The default scripts are configured for the NOAA AWS Cloud Service Provider
environment and assume the following:

- The scripts are submitted from the `mpi-tests-intel` working directory.
- The container image is one directory above the working directory.
- The scheduler is Slurm.
- MPI ranks are launched with `srun --mpi=pmi2`.
- The host has either `singularity` or `apptainer` in `PATH`. The scripts
  check for `singularity` first, then `apptainer`.
- If neither runtime is found in the default host `PATH`, users may need to
  load the matching host module by uncommenting the appropriate line near the
  top of the job script.
- Intel MPI inside the container pairs with the host Slurm PMI-2. If ranks do
  not form a single job, set `I_MPI_PMI_LIBRARY` to the host `libpmi2.so`
  (bind-mounted into the container).
- The container image includes the Intel oneAPI compilers, Intel MPI, and the
  oneAPI module files.
- The bash shell is used for the command line and scripts

Other systems may require changes to the Slurm directives, account name,
queue or partition, container image name, and MPI runtime environment.


## Running the `hello-world-parallel` Test

The steps below describe the workflow used by the scripts. Submit the scripts
from the `mpi-tests-intel` directory. The scripts set `work_dir` from
`SLURM_SUBMIT_DIR` and set `base_dir` to the parent directory of `work_dir`.
The container image is expected at:

```bash
${base_dir}/rocky9-oneapi2024.2-ss192.sif
```

For example, if the repository is staged as
`/some/filesystem/mpi-tests-intel`, place the image at
`/some/filesystem/rocky9-oneapi2024.2-ss192.sif`.

### 1. Obtain or build a Singularity/Apptainer image

Obtain or build a container image that includes the Intel oneAPI compiler
suite, Intel MPI, and the required runtime environment. This is the image
produced by this recipe: the spack-stack container combined with the Intel
oneAPI compiler image so that the compilers are reinstalled in the final
image.

```bash

cd /some/filesystem
# Replace with the actual image location for your site.

export img=/some/filesystem/rocky9-oneapi2024.2-ss192.sif
```

If `singularity` is not available but `apptainer` is, use `apptainer pull`
instead. The batch scripts check for `singularity` first and `apptainer`
second.

---

### 2. Stage the test directory on the host

If the `mpi-tests-intel` directory is included in the container image, copy it
from the image to the host filesystem. The example below bind-mounts the base
directory into the container and stages the test directory there.

```bash
container_cmd=singularity
command -v "${container_cmd}" >/dev/null 2>&1 || container_cmd=apptainer
base_dir=/some/filesystem
"${container_cmd}" exec -B "${base_dir}:${base_dir}" "${img}" \
    cp -r /opt/mpi-tests-intel "${base_dir}/."
```

---

### 3. Start an interactive shell inside the container

Start an interactive shell with the host working filesystem bind-mounted into
the container.

```bash
container_cmd=singularity
command -v "${container_cmd}" >/dev/null 2>&1 || container_cmd=apptainer
base_dir=/some/filesystem
"${container_cmd}" shell -B "${base_dir}:${base_dir}" "${img}"
```

Initialize Lmod and load the Intel oneAPI compiler and Intel MPI environment:

```bash
source /usr/share/lmod/lmod/init/bash
module use /opt/intel/oneapi/2024.2/etc/modulefiles
module load tbb/2021.13 compiler-rt/2024.2.1 compiler/2024.2.1 mkl/2024.2 ifort/2024.2.1 mpi/2021.13
module list
```

Alternatively, if the image provides a shell environment file, source it to set
up the module search paths, then load the modules above:

```bash
source /opt/spack-stack/spack-stack-1.9.2/.bashenv
```

---

### 4. Build the executables

After entering the container and loading the Intel oneAPI / Intel MPI
environment, change to the staged test directory (see Step 2):

```bash
cd /some/filesystem/mpi-tests-intel
```
You can build the executables using one of the following methods.

#### Option A: Build with the Makefile

```bash
make clean
make
```

#### Option B: Build manually with `mpiifort`

```bash
make clean
mpiifort -o hello-world-parallel hello-world-parallel.f90
mpiifort -o hello-world hello-world.f90
```

After building the executables with Option A or Option B, exit the container:

```bash
exit
```

#### Option C: Build with a batch script

The executables can also be built from the host by submitting the batch script
`job_compile.sh`.

Before submitting the script, edit it for the target system. In particular,
check the Slurm directives, account name, queue or partition, and container
image name. If neither `singularity` nor `apptainer` is in the default host
`PATH`, load the matching host module by uncommenting or adapting one of the
module hints near the top of the script:

```bash
#module load apptainer
#module load singularity
```

Submit from the `mpi-tests-intel` directory:

```bash
sbatch job_compile.sh
```

---

## Running MPI Jobs

The examples below run the `hello-world-parallel` executable using Slurm batch
scripts. The default scripts are configured for the AWS environment and may
need to be edited on other systems.

At minimum, check the following items before submitting the scripts:

- Slurm directives, such as `--account`, `--qos`, `--partition`, `--nodes`,
  and `--ntasks-per-node`
- the container image name and location
- whether `singularity` or `apptainer` is available on the host
- the wrapper script path, where applicable

The examples assume that Slurm launches MPI tasks with `srun --mpi=pmi2` and
that the container Intel MPI can use the host Slurm PMI-2.

---

### 5. Run an MPI application 

The script `job_script.sh` submits two-node Slurm jobs to run ``hello-world-parallel``, 
with or without (a default) arguments for the executable.

In these examples Slurm starts MPI tasks with `srun`. Each task starts a
container instance (one instance per task) and runs the MPI executable inside it. 

This workflow assumes that:

- The host Slurm provides the `pmi2` plugin (`srun --mpi=pmi2`).
- The container Intel MPI uses the host Slurm PMI-2, if needed via
  `I_MPI_PMI_LIBRARY` set to the host `libpmi2.so` (bind-mounted into the
  container).
- The container Intel MPI runtime is compatible with the host Slurm PMI-2.

The script checks for `singularity` first, then `apptainer`, stores the selected
runtime in `container_cmd`, and launches ranks with `srun --mpi=pmi2`. It binds
the parent of the submit directory into the same path inside the container.

The script sets `SINGULARITY_SHELL`. Any variable that must reach the MPI
process inside the container is passed with a `SINGULARITYENV_` prefix for
Singularity compatibility. If `srun`-launched ranks do not form a single MPI
job, or to tune the fabric, set the Intel MPI knobs the same way, for example:

```bash
export SINGULARITYENV_I_MPI_PMI_LIBRARY=/usr/lib64/slurm/libpmi2.so
export SINGULARITYENV_I_MPI_FABRICS=shm:ofi
export SINGULARITYENV_FI_PROVIDER=tcp
```

For Apptainer-native environments, the corresponding `APPTAINERENV_*`
variables can also be used.

For larger jobs, the script includes an optional startup stagger:

```bash
export SINGULARITYENV_STARTUP_STAGGER_SECONDS=0
```

Leave it at `0` for short test jobs. Increase it to spread container startup
across ranks and reduce pressure on shared filesystems.

Adjust these for your interconnect. This example has been tested on NOAA RDHPC
systems (Ursa, Hera, Gaea, MSU Hercules/Orion, NOAA Cloud AWS/Azure).

#### Run the job_script.sh without command-line arguments

After adapting to your host system, submit the batch script from the
`mpi-tests-intel` directory:

```bash
sbatch job_script.sh
```

The expected output in the `out` file should look similar to the following.
The rank order may vary.

```text
 Hello, World! I am process           0 of          16
 Hello, World! I am process           8 of          16
 Hello, World! I am process           1 of          16
 Hello, World! I am process           2 of          16
 Hello, World! I am process           5 of          16
 Hello, World! I am process           3 of          16
 Hello, World! I am process           6 of          16
 Hello, World! I am process           7 of          16
 Hello, World! I am process           4 of          16
 Hello, World! I am process           9 of          16
 Hello, World! I am process          10 of          16
 Hello, World! I am process          11 of          16
 Hello, World! I am process          12 of          16
 Hello, World! I am process          13 of          16
 Hello, World! I am process          15 of          16
 Hello, World! I am process          14 of          16
```

#### Run the job_script.sh with command-line argument to the executable

To adapt the script for command-line arguments passed to `hello-world-parallel`
executable, replace the line containing the executable name in the `job_script.sh`
with the following:

```bash
     ./hello-world-parallel "$1" "$2" "$3"
     ' bash "${nprocs}" "${nnodes}" "${ntpn}"
```
Proceed to submit it with `sbatch` as in the previous example.

The output of the modified script should be similar to the
previous example. Additionally, each rank also reports the command-line
arguments passed to it, similar to the following.

```text
 Number of arguments:           3
 Arguments provided:
 Argument           1 :16
 Argument           2 :2
 Argument           3 :8
 Hello, World! I am process           4 of          16

 Number of arguments:           3
 Arguments provided:
 Argument           1 :16
 Argument           2 :2
 Argument           3 :8
 Hello, World! I am process           8 of          16

 Number of arguments:           3
 Arguments provided:
 Argument           1 :16
 Argument           2 :2
 Argument           3 :8
 Hello, World! I am process           0 of          16

 ...
```
... and so on for all the ranks.

---
