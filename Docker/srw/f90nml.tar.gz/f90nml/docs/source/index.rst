.. include:: ../../README.rst

Contents
========

.. toctree::

   usage
   cli
   notes
   contributing


Licensing
=========

``f90nml`` is distributed under the `Apache 2.0 License`_.

.. _Apache 2.0 License:
    http://www.apache.org/licenses/LICENSE-2.0.txt


Contact
=======

Marshall Ward <f90nml@marshallward.org>
