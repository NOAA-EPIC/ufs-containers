export MODULEPATH=/opt/intel/oneapi/2024.2/etc/modulefiles:/etc/modulefiles:/usr/share/modulefiles
export MODULES_AUTO_HANDLING=1
export MODULESHOME=/usr/share/lmod/lmod

