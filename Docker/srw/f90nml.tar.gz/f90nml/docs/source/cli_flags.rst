-f FORMAT, --format FORMAT    specify the output format (json, yaml, or nml)

-g GROUP, --group GROUP       specify namelist group to modify.  When absent,
                              the first group is used

-h, --help                    display this help and exit

-p, --patch                   modify the existing namelist as a patch

-v EXPR, --variable EXPR      specify the namelist variable to add or modify,
                              followed by the new value.  Expressions are of
                              the form "VARIABLE=VALUE"

--version                     output version information and exit
