#README file in the ./hello-world-mpi/ directory

This directory contains Fortran test programs for verifying OpenMPI built with the GNU compiler suite when running across multiple nodes on a host system. 
The test programs (hello-world.f90 and hello-world-parallel.f90) are compiled inside a Singularity container, and the resulting executables are run from the host, using a wrapper script that launches them inside the same container.


The directory also includes example job_card and wrapper.sh scripts for two environments:
- NOAA AWS Cloud Service Provider (*_AWS)
- MSU Hercules Cluster (*_Hercules)

Notes:
- Hercules uses srun instead of mpirun.
- Hercules requires binding an additional directory, /local, into the container because the scheduler uses it for temporary files.
- The default job_card and wrapper.sh provided are the AWS versions.
- A default job_card and wrapper.sh are for AWS.

Running the hello-world-parallel Test

Below are the steps for AWS.
(For Hercules, the same steps apply, but different directories must be bound when shelling into the container.)

1. Build the singularity container image from DockerHub, e.g.:

```
singularity build rocky9-ss192-gcc13.sif docker://noaaepic/rocky9-gcc13.3.1-spack-stack:v1.9.2-ufs-wm-srw
img=$PWD/rocky9-ss192-gcc13.sif
```

2. Build the test executables

Assume you are in the directory ./hello-world-mpi/ containing:
hello-world.f90
hello-world-parallel.f90
Makefile

```
singularity shell -B /contrib $img
source /usr/share/lmod/lmod/init/bash
module use /opt/modulefiles
module load gnu openmpi
make clean
```

Build using either make or mpif90:
(a) Using Makefile
```
make 
```
    OR
```
make hello-world-parallel
```

(b) Using mpif90 directly
```
mpif90 -o hello-world-parallel hello-world-parallel.f90
```

Exit from the container:
```
exit
```

3. Organize executables and set up wrapper

Move the binaries into the ./bin directory, which is added to the $PATH when the Singularity container runs.
```
mv hello-world-parallel ./bin/.
ln -s wrapper.sh hello-world-parallel
```
Update wrapper.sh for your environment:
i) PATH modification:
Set
export SINGULARITYENV_PREPEND_PATH=/<full-path-to>/bin:...

ii) Container image path:
Update
img=/full/path/to/rocky9-gcc13-openmpi416-pmi2-slurm.sif

iii) Bind paths:
AWS:
-B /contrib

Hercules:
-B /work/noaa/epic -B /local


4. Modify and submit the job card

Ensure the job card changes into the working directory before launching.
The included example runs on 2 nodes with 16 CPUs per node.

Submit:
```
sbatch < job_card
```

5. Expected Output

If successful, the job output will appear in the out file and will resemble:
```
 Hello, World! I am process           5 of          32
 Hello, World! I am process           8 of          32
 Hello, World! I am process          11 of          32
 Hello, World! I am process          14 of          32
 Hello, World! I am process          15 of          32
 Hello, World! I am process           0 of          32
 Hello, World! I am process           2 of          32
 Hello, World! I am process           6 of          32
 Hello, World! I am process           9 of          32
 Hello, World! I am process           1 of          32
 Hello, World! I am process           3 of          32
 Hello, World! I am process           4 of          32
 Hello, World! I am process           7 of          32
 Hello, World! I am process          10 of          32
 Hello, World! I am process          12 of          32
 Hello, World! I am process          13 of          32
 Hello, World! I am process          24 of          32
 Hello, World! I am process          25 of          32
 Hello, World! I am process          16 of          32
 Hello, World! I am process          17 of          32
 Hello, World! I am process          18 of          32
 Hello, World! I am process          21 of          32
 Hello, World! I am process          22 of          32
 Hello, World! I am process          27 of          32
 Hello, World! I am process          28 of          32
 Hello, World! I am process          19 of          32
 Hello, World! I am process          20 of          32
 Hello, World! I am process          23 of          32
 Hello, World! I am process          26 of          32
 Hello, World! I am process          29 of          32
 Hello, World! I am process          30 of          32
 Hello, World! I am process          31 of          32
```
