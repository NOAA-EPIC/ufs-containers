program hello_world_mpi
    use MPI
    implicit none

    integer :: rank, size, ierr

    ! Initialize MPI
    call mpi_init(ierr)
    if (ierr /= 0) then
        write(*,*) 'Error initializing MPI: ', ierr
        stop
    end if

    ! Get the rank and size of the process
    call mpi_comm_rank(mpi_comm_world, rank, ierr)
    if (ierr /= 0) then
        write(*,*) 'Error getting rank: ', ierr
        call mpi_finalize(ierr)
        stop
    end if

    call mpi_comm_size(mpi_comm_world, size, ierr)
    if (ierr /= 0) then
        write(*,*) 'Error getting size: ', ierr
        call mpi_finalize(ierr)
        stop
    end if

    ! Print a greeting message
    write(*,*) 'Hello, World! I am process', rank, 'of', size

    ! Finalize MPI
    call mpi_finalize(ierr)

end program hello_world_mpi

