#!/bin/bash
#set -x
export SINGULARITYENV_FI_PROVIDER=tcp
export SINGULARITY_SHELL=/bin/bash
export SINGULARITYENV_CPATH=/opt/slurm/include:/opt/openmpi/4.1.6/include:/opt/rh/gcc-toolset-13/root/usr/include
export SINGULARITYENV_PREPEND_PATH=/contrib/Natalie.Perlin/hello-mpi-world/bin:/opt/openmpi/4.1.6/bin:/opt/rh/gcc-toolset-13/root/usr/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export SINGULARITYENV_LD_LIBRARY_PATH=/opt/slurm/lib:/opt/openmpi/4.1.6/lib:/opt/rh/gcc-toolset-13/root/usr/lib64:/opt/rh/gcc-toolset-13/root/usr/lib:/lib64:/.singularity.d/libs
export SINGULARITYENV_LIBRARY_PATH=/opt/slurm/lib:/opt/openmpi/4.1.6/lib:/opt/rh/gcc-toolset-13/root/usr/lib64:/opt/rh/gcc-toolset-13/root/usr/lib:/lib64
export SINGULARITYENV_PMIX_MCA_gds=hash
export SINGULARITYENV_OMPI_MCA_btl="^openib"
if ip link show eth0 &>/dev/null; then
  export SINGULARITYENV_OMPI_MCA_btl_tcp_if_include=eth0
fi
export SINGULARITYENV_OMPI_MCA_pml=ob1
export SINGULARITYENV_OMPI_MCA_mca_base_component_show_load_errors=0
img="/contrib/Natalie.Perlin/CONTAINER_TESTS/rocky9-gcc13-openmpi416-pmi2-slurm.sif"
cmd=$(basename "$0")
SINGULARITY=$(which singularity)
"${SINGULARITY}" exec -B /contrib "${img}" $cmd
