#!/bin/bash
#set -x
export APPTAINERENV_FI_PROVIDER=tcp
export SINGULARITY_SHELL=/bin/bash

cmd=$(basename "$0")
arg="$@"
echo "args are $arg"
echo running: singularity exec "${img}" $cmd $arg
rootdir=${PWD%${PWD#/*/}}
/usr/bin/singularity exec -B $rootdir -e "${img}" $cmd $arg

