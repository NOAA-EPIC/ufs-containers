program hello_world_mpi
    use MPI
    implicit none

    integer :: rank, size, ierr
    integer :: i, nargs
    character(len=256) :: arg

    ! Initialize MPI
    call mpi_init(ierr)
    if (ierr /= 0) then
        write(*,*) 'Error initializing MPI: ', ierr
        stop
    end if

    ! Get the rank and size of the process
    call mpi_comm_rank(mpi_comm_world, rank, ierr)
    if (ierr /= 0) then
        write(*,*) 'Error getting rank: ', ierr
        call mpi_finalize(ierr)
        stop
    end if

    call mpi_comm_size(mpi_comm_world, size, ierr)
    if (ierr /= 0) then
        write(*,*) 'Error getting size: ', ierr
        call mpi_finalize(ierr)
        stop
    end if

    nargs = command_argument_count()

    ! Print number of arguments, if any, and list them:
    if (nargs >= 1) then
      write(*,*) 'Number of arguments:', nargs
      write(*,*) 'Arguments provided:'       

      do i = 1, nargs
        call get_command_argument(i, arg)
        write(*,*) 'Argument', i, ':', trim(arg)
      enddo
    endif

    ! Print a greeting message
    write(*,*) 'Hello, World! I am process', rank, 'of', size

    ! Finalize MPI
    call mpi_finalize(ierr)

end program hello_world_mpi

