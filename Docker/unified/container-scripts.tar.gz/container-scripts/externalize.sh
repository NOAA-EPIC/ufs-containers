#!/bin/bash

################################################################################
# Help                                                                         #
################################################################################
Help()
{
   # Display Help
   echo "Add description of the script functions here."
   echo
   echo "Syntax: scriptTemplate [-g|h|v|V]"
   echo "options:"
   echo "g     Print the GPL license notification."
   echo "h     Print this Help."
   echo "v     Verbose mode."
   echo "V     Print software version and exit."
   echo
}

################################################################################
################################################################################
# Main program                                                                 #
################################################################################
################################################################################
################################################################################
# Process the input options. Add options as needed.                            #
################################################################################
# Get the options
while getopts ":he" option; do
   case $option in
      h) # display Help
         Help
         exit;;
      e) # external directory to hold externalized executables
         exec_dir=$2
         echo "Will create external executable in $exec_dir"
   esac
done
shift $(($OPTIND ))
fileList=$@

mkdir -p $exec_dir
cp /opt/container-scripts/run_container_executable.sh $exec_dir
cp /opt/container-scripts/build_container_executable.sh $exec_dir
#replace the paths in the script
sed -i "s|IMAGE|$SINGULARITY_CONTAINER|g" $exec_dir/*_executable.sh
nbinds=`echo $SINGULARITY_BIND | awk -F "," '{print NF }'`
bindstring=" "
for (( i = 1; i <= $nbinds; i++ )); do binddir=`echo $SINGULARITY_BIND | cut -d "," -f $i` && bindstring="${bindstring} -B ${binddir}" ; done
echo $bindstring
sed -i "s|BINDDIRS|$bindstring|g" $exec_dir/*_executable.sh
sed -i "s|LDLIB_PATH|$LD_LIBRARY_PATH|g" $exec_dir/*_executable.sh
sed -i "s|LIB_PATH|$LIBRARY_PATH|g" $exec_dir/*_executable.sh

for file in $fileList
do
  fullfile=$(readlink -m $file)
  basefile=$(basename "$fullfile")
  cp $exec_dir/run_container_executable.sh $exec_dir/$basefile
  pathdir=$(dirname $fullfile)
  echo "fullfile is $fullfile"
  echo $pathdir
 
  EXEC_PATH="$pathdir:$PATH"
  sed -i "s|EXEC_PATH|$EXEC_PATH|g" $exec_dir/$basefile
  sed -i "s|ESMF_MK|$ESMFMKFILE|g" $exec_dir/$basefile
done
fileList="make cmake ecbuild python python3"
for file in $fileList
do
  fullfile=$(which $file)
  basefile=$(basename "$fullfile")
  cp $exec_dir/build_container_executable.sh $exec_dir/$basefile
  pathdir=$(dirname $fullfile)
 
  EXEC_PATH="$pathdir:$PATH"
  sed -i "s|EXEC_PATH|$EXEC_PATH|g" $exec_dir/$basefile
  sed -i "s|CMAKE_PREPATH|$CMAKE_PREFIX_PATH|g" $exec_dir/$basefile
  sed -i "s|ESMF_MK|$ESMFMKFILE|g" $exec_dir/$basefile
done

#singularity exec -H $PWD $IMAGE cp /opt/ufs-weather-model/container-scripts/run_container_executable.sh .
#singularity exec -H $PWD $IMAGE cp /opt/ufs-weather-model/container-scripts/build_container_executable.sh .
#mkdir -p bin
#cd bin
#ln -s ../build_container_executable.sh make
#ln -s ../build_container_executable.sh cmake
#cd ..
#export line=`/bin/grep -n "cp ${PATHRT}" tests/run_test.sh | /bin/grep fv3.exe | awk -F ":" '{print $1}'`
#sed -i "${line}s/^/#/g" tests/run_test.sh
#sed -i "${line}a ln -s \$\{PATHRT\}\/..\/run_container_executable.sh fv3_\$\{COMPILE_NR\}.exe" tests/run_test.sh
#sed -i 's/srun/#srun/g' tests/fv3_conf/fv3_slurm.IN*
#sed -i '/#srun/a mpiexec -n @[TASKS] ./fv3_${COMPILE_NR}.exe' tests/fv3_conf/fv3_slurm.IN*
#
#SINGULARITY=`which singularity`
#LOCDIR=`echo $PWD | awk -F "/" '{print $2}'`
#
##replace the paths in the script
#sed -i "s|IMAGE|$IMAGE|g" *_executable.sh
#sed -i "s|LOCDIR|$LOCDIR|g" *_executable.sh
#sed -i "s|DATADIR|$DATADIR|g" *_executable.sh
#sed -i "s|UFSPATH|$PWD/tests|g" *_executable.sh
#sed -i "s|PATH_TO_SINGULARITY|$SINGULARITY|g" *_executable.sh
#
#for FILE in modulefiles/*intel.lua; do echo "prepend_path(\"PATH\", \"$PWD/bin\")" >> $FILE ; done
